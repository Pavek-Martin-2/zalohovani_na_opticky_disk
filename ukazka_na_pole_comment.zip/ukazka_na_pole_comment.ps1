﻿cls
# ukazka na komentar v poly, pole rozradkovane vs. klasicke pole

$p1 = @(
"a",
"b",
#"c",
"d"
)

$d_p1 = $p1.Length
echo $d_p1
foreach ($i1 in $p1) { echo $i1 }

$p2 = @("A", "B", #"C" ,"D") # tady je vydet ze takto to ani nejde 
$d_p2 = $p.Length
echo $d_p2
foreach ($i2 in $p2) { echo $i2 }
